//
//  LoginViewController.swift
//  SalaryCalculator
//
//  Created by mickeytora on 2022/3/25.
//

import UIKit

class LoginViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
}
