//
//  ResultViewController.swift
//  SalaryCalculator
//
//  Created by mickeytora on 2022/7/22.
//

import UIKit

class ResultViewController: UITableViewController {
        
    var sectionTitleOne = ["姓名","社保基数","应发工资","住房公积金公司缴纳","住房公积金个人缴纳","综合货币待遇"]

    //數據數組
    static var dataOneArray = [String](repeating: "", count: 6)
    static var reserved_salary = ""
    
    override func viewDidLoad() {
           
           super.viewDidLoad()

           self.tableView.reloadData()
        
           //標題的顯示
           self.title = "计算结果"
           
           self.view.backgroundColor = .white
           
           self.tableView.reloadData()
           //tableView delegate 和 dataSource 的顯示
           self.tableView.dataSource = self
           self.tableView.delegate = self
         
           //右導航按鈕顏色設置
           self.navigationItem.rightBarButtonItem?.tintColor = UIColor.black
           
           print("This is ResultTableView Controller")
           print("This is TableView ResultTwoViewController dataArray", ResultTwoViewController.dataArray)
           print("data Array count",ResultTwoViewController.dataArray.count)
    }
    
    //TODO:-導出PDF（尚未開發）
    @objc func deriveToPDF() {
        
           print("deriveToPDF button press")
        
           //定義
           let derivationJSON: [String: Any] =  ["accumulation_fund_company":ResultTwoViewController.dataArray[5], "accumulation_fund_individual":ResultTwoViewController.dataArray[6],
            "comprehensive_salary": ResultTwoViewController.dataArray[7],
            "reserved_salary": ResultTwoViewController.reserved_salary,
            "should_pay": ResultTwoViewController.dataArray[2],
            "social_insurance_company": ResultTwoViewController.dataArray[3],
            "social_insurance_individual": ResultTwoViewController.dataArray[4],
            "social_security_cardinal_number": ResultTwoViewController.dataArray[1],
            "user_name": ResultTwoViewController.dataArray[0]]
         
            print(derivationJSON)
 
            let jsonData = try? JSONSerialization.data(withJSONObject: derivationJSON)

            //設置url地址
            let url = URL(string: "http://192.168.31.21:8083/mock/762070/createPDF")!
 
            //設置request請求
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.setValue("\(String(describing: jsonData?.count))", forHTTPHeaderField: "Content-Length")
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
         
            //將json插入請求
            request.httpBody = jsonData

           //傳輸數據並且處理返回數據
           let task = URLSession.shared.dataTask(with: request) { [self] data, response, error in
                guard let data = data, error == nil else {
                    print(error?.localizedDescription ?? "No data")
                    return
                }
    
                let responseJSON = try? JSONSerialization.jsonObject(with: data, options: [])
         
                print("this is responsJSON",responseJSON)
 
                var responseJSONData: [String: Any]
                if let responseJSONData = responseJSON as? [String: Any] {
                    print("this is the resonseJSONData",responseJSONData) //Code after Successfull POST R
                }
          }
          task.resume()
    }
    
    //MARK:-TableView Delegate和DataSource設置
    //设置tableView有多少个部分
    override func numberOfSections(in tableView: UITableView) -> Int {
        return sectionTitleOne.count
    }

    //设置tableView每个部分的Header的高
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
           return 30
    }

    //设置tableView每个部分Header内容
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
            let view = UIView()
            view.backgroundColor = UIColor(red:0.94, green:0.94, blue:0.94, alpha:1.0)
            // view.backgroundColor = UIColor.systemBlue
            let viewLabel = UILabel(frame: CGRect(x: 10, y: 0, width: UIScreen.main.bounds.size.width, height: 30))
               //viewLabel.text = data[section].0
              
            viewLabel.text = sectionTitleOne[section]
        
            // viewLabel.textColor = UIColor(red:0.31, green:0.31, blue:0.31, alpha:1.0)
            viewLabel.textColor = UIColor.black
            view.addSubview(viewLabel)
            tableView.addSubview(view)
            return view
    }

    //计算每个部分的数量
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return 1
    }

    //将数据填充到UITableViewCell里
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let identifier = "reusedCell"
            var cell = tableView.dequeueReusableCell(withIdentifier: identifier)
        
            if (cell == nil) {
                cell = UITableViewCell(style: .default, reuseIdentifier: identifier)
            }
        
            let rowNum = (indexPath as NSIndexPath).section
            cell?.textLabel?.text = ResultViewController.dataOneArray[rowNum]
        
            return cell!
     }
}
