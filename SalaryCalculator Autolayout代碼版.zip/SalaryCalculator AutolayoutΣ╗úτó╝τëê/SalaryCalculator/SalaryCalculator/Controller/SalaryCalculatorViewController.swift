//
//  SalaryCalculator.swift
//  SalaryCalculator
//
//  Created by mickeytora on 2022/3/8.
//

import UIKit

class SalaryCalculatorViewController: UIViewController, UITextFieldDelegate {
   
    //MARK:-添加控件
    //SegmentedControl控件
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    
    //Switch控件
    @IBOutlet weak var payTypeSwitch: UISwitch!
    @IBOutlet weak var identitySwitch: UISwitch!
    
    //Label控件
    @IBOutlet weak var payUpLabel: UILabel!
    @IBOutlet weak var reservedLabel: UILabel!
    @IBOutlet weak var shenhuLabel: UILabel!
    @IBOutlet weak var unshenhuLabel: UILabel!
    @IBOutlet weak var monthlyIncomeLabel: UILabel!
    @IBOutlet weak var reservedIncomeLabel: UILabel!
    
    //TextField控件
    @IBOutlet weak var monthlyIncomeTextField: UITextField!
    @IBOutlet weak var reservedTextField: UITextField!
    
    //Button控件
    @IBOutlet weak var calculateButton: UIButton!
    @IBOutlet weak var resetButton: UIButton!
    
    static var calculateType: Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        print("this is salarycalculatorviewcontroller")
        
        //設置標題
        self.title = "薪酬计算"
                
        //設置segmentedControl
        self.view.addSubview(segmentedControl)
        self.segmentedControl.translatesAutoresizingMaskIntoConstraints = false
        let font = UIFont.systemFont(ofSize: 17)
        self.segmentedControl.setTitleTextAttributes([NSAttributedString.Key.font: font], for: .normal)
    
        //添加switch到View
        self.view.addSubview(payTypeSwitch)
        self.view.addSubview(identitySwitch)
        self.payTypeSwitch.translatesAutoresizingMaskIntoConstraints = false
        self.identitySwitch.translatesAutoresizingMaskIntoConstraints = false
        
        //設置switch  
        self.payTypeSwitch.setOn(false, animated: true)
        self.identitySwitch.setOn(false, animated: true)
        
        //添加Label
        self.view.addSubview(payUpLabel)
        self.view.addSubview(reservedLabel)
        self.view.addSubview(shenhuLabel)
        self.view.addSubview(unshenhuLabel)
        self.view.addSubview(monthlyIncomeLabel)

        //標題的設置
        self.monthlyIncomeLabel.text = "综合薪酬"
        setMonthlyIncomeLabelText()
        
        //關閉控件translatesAutoresizingMaskIntoConstraints
        self.payUpLabel.translatesAutoresizingMaskIntoConstraints = false
        self.reservedLabel.translatesAutoresizingMaskIntoConstraints = false
        self.shenhuLabel.translatesAutoresizingMaskIntoConstraints = false
        self.unshenhuLabel.translatesAutoresizingMaskIntoConstraints = false
        self.monthlyIncomeLabel.translatesAutoresizingMaskIntoConstraints = false
        self.reservedIncomeLabel.translatesAutoresizingMaskIntoConstraints = false
        
        //添加TextField
        self.view.addSubview(monthlyIncomeTextField)
        self.view.addSubview(reservedTextField)
    
        //AutoLayout設置，關閉控件的translatesAutoresizingMaskIntoConstraints
        self.monthlyIncomeTextField.translatesAutoresizingMaskIntoConstraints = false
        self.reservedTextField.translatesAutoresizingMaskIntoConstraints = false
        
        //設置textField外表為圓角
        self.monthlyIncomeTextField.borderStyle = UITextField.BorderStyle.roundedRect
        self.reservedTextField.borderStyle = UITextField.BorderStyle.roundedRect
        
        //設置masksToBounds為true
        self.monthlyIncomeTextField.layer.masksToBounds = true
        self.reservedTextField.layer.masksToBounds = true
        
        //設置圓角半徑
        self.monthlyIncomeTextField.layer.cornerRadius = 12.0
        self.reservedTextField.layer.cornerRadius = 12.0
       
        //設置邊框寬度
        self.monthlyIncomeTextField.layer.borderWidth = 1.0
        self.reservedTextField.layer.borderWidth = 1.0
        
        //默認值的設置
        self.reservedTextField.text = "0"
        self.reservedTextField.isEnabled = false

        //設置邊框線條顏色
        self.monthlyIncomeTextField.layer.borderColor = UIColor.black.cgColor
        self.reservedTextField.layer.borderColor = UIColor.black.cgColor

        //設置textfield siztToFit
        self.monthlyIncomeTextField.sizeToFit()
        self.reservedTextField.sizeToFit()

        //添加Button
        self.view.addSubview(calculateButton)
        self.view.addSubview(resetButton)
        self.calculateButton.translatesAutoresizingMaskIntoConstraints = false
        self.resetButton.translatesAutoresizingMaskIntoConstraints = false
        
        //設置按鈕
        self.calculateButton.isEnabled = true
        self.resetButton.isEnabled = true
        self.calculateButton.isUserInteractionEnabled = true
        self.resetButton.isUserInteractionEnabled = true
        
        //設置按鈕圓角
        self.calculateButton.layer.cornerRadius = 12.0
        self.resetButton.layer.cornerRadius = 12.0
        
        self.calculateButton.sizeToFit()
        self.resetButton.sizeToFit()
        
        //設置界面可交換
        self.view.isUserInteractionEnabled = true
        
        //設置TextField
        self.monthlyIncomeTextField.keyboardType = .decimalPad
        self.reservedTextField.keyboardType = .decimalPad

        //設置textField的delegate
        self.monthlyIncomeTextField.delegate = self
        self.reservedTextField.delegate = self
        
        //給按鈕添加函數
        self.calculateButton.addTarget(self, action: #selector(calculate), for: .touchUpInside)
        self.resetButton.addTarget(self, action: #selector(reset), for: .touchUpInside)
                
        //給開關設置函數
        self.payTypeSwitch.addTarget(self, action: #selector(payTypeSwitchValueChange), for: .valueChanged)
        
        //設置AutoLayout
        setAutoLayout()
    }
    
    //設置AutoLayout
    func setAutoLayout() {
       
         //SegmentedControl
         self.segmentedControl.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
         self.segmentedControl.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 100).isActive = true
         self.segmentedControl.widthAnchor.constraint(equalToConstant: 160).isActive = true
         self.segmentedControl.heightAnchor.constraint(equalToConstant: 32).isActive = true
        
        //PayUpLabel(全額標籤）
        self.payUpLabel.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 160).isActive = true
        self.payUpLabel.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 50).isActive = true
         
        //ReseredLabel（非全額標籤）
        self.reservedLabel.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 160).isActive = true
        self.reservedLabel.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -40).isActive = true
        
        //shenhuLabel（深戶標籤）
        self.shenhuLabel.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 200).isActive = true
        self.shenhuLabel.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 50).isActive = true
        
        //UnshenhuLabel（非深戶標籤）
        self.unshenhuLabel.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 200).isActive = true
        self.unshenhuLabel.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -40).isActive = true
        
        //PayTypeSwitch（支付類型選擇開關）
        self.payTypeSwitch.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 160).isActive = true
        self.payTypeSwitch.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        
        //ShenHuSwitch（戶籍類型選擇開關）
        self.identitySwitch.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 200).isActive = true
        self.identitySwitch.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        
        //MonthlyIncomeLabel（綜合薪酬標籤）
        self.monthlyIncomeLabel.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 250).isActive = true
        self.monthlyIncomeLabel.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 26).isActive = true

        //ReserIncomeLabel（獎金標籤）
        self.reservedIncomeLabel.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 312).isActive = true
        self.reservedIncomeLabel.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 50).isActive = true
        
        //MonthlyIncomeTextField（綜合薪酬文本框）
        self.monthlyIncomeTextField.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 250).isActive = true
        self.monthlyIncomeTextField.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 138).isActive = true
        self.monthlyIncomeTextField.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -20).isActive = true
        self.monthlyIncomeTextField.heightAnchor.constraint(equalToConstant: 30).isActive = true
        
        //ReservedTextField（獎金文本框）
        self.reservedTextField.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 310).isActive = true
        self.reservedTextField.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 138).isActive = true
        self.reservedTextField.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -20).isActive = true
        self.reservedTextField.heightAnchor.constraint(equalToConstant: 30).isActive = true
        
        //CalculateButton(計算按鈕）
        self.calculateButton.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 360).isActive = true
        self.calculateButton.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 60).isActive = true
        self.calculateButton.widthAnchor.constraint(equalToConstant: 70).isActive = true
        
        //ResetButton(重置按鈕）
        self.resetButton.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 360).isActive = true
        self.resetButton.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -60).isActive = true
        self.resetButton.widthAnchor.constraint(equalToConstant: 70).isActive = true
     }
    
    //Segment標籤字體的設置
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

        _ = segmentedControl.subviews.compactMap { $0.subviews.compactMap {
            ($0 as? UILabel)?.adjustsFontSizeToFitWidth = true
            ($0 as? UILabel)?.minimumScaleFactor = 0.5
        }}
    }
    
    //设置monthlyIncomeLabel的text
    func setMonthlyIncomeLabelText() {
        if (segmentedControl.selectedSegmentIndex == 0) {
            self.monthlyIncomeLabel.text = "综合薪酬"
        }
        if (segmentedControl.selectedSegmentIndex == 1) {
            self.monthlyIncomeLabel.text = "应发工资"
        }
    }
 
    //MARK:-鍵盤彈出設置
    //設置鍵盤彈出效果
    override func viewWillAppear(_ animated: Bool) {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    @objc func keyboardWillShow(notification: NSNotification) {
        guard let userInfo = notification.userInfo else {return}
        guard let keyboardSize = userInfo[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue else {return}
              let keyboardFrame = keyboardSize.cgRectValue
              if self.view.bounds.origin.y == 0 {
                    self.view.bounds.origin.y += keyboardFrame.height - 220
              }
    }

    @objc func keyboardWillHide(notification: NSNotification) {
        if self.view.bounds.origin.y != 0 {
           self.view.bounds.origin.y = 0
        }
    }
    
    //設置當點View時收回鍵盤
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    //設置當按回車時回收鍵盤
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.monthlyIncomeTextField.resignFirstResponder()
        self.reservedTextField.resignFirstResponder()
        
        return true
    }

    //發送個人數據並且處理數據
    func postPersonalData() {
        
        //設置JSON數據
        let personnalJSON: [String: Any] = ["shenzhen_registered": self.identitySwitch.isOn ? "0":"1", "pay_mode": self.payTypeSwitch.isOn ? "reserved":"pay_up", "salary": self.monthlyIncomeTextField.text!, "reserved_salary": self.reservedTextField.text]
                
                print("this is postPersonData")
                print("this is personalJSON",personnalJSON)
                print("this is postPersonalData again")
               
                let jsonData = try? JSONSerialization.data(withJSONObject: personnalJSON)

                //設置url地址
                let url = URL(string: "http://192.168.31.22:8083/salaryCalculateIndividual")!
                       
                //設置request請求
                var request = URLRequest(url: url)
                request.httpMethod = "POST"
                request.setValue("\(String(describing: jsonData?.count))", forHTTPHeaderField: "Content-Length")
                request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                
                //將json插入請求
                request.httpBody = jsonData
                
                //傳輸數據並且處理返回數據
                let task = URLSession.shared.dataTask(with: request) { [self] data, response, error in
                    guard let data = data, error == nil else {
                        print(error?.localizedDescription ?? "No data")
                        return
                    }
                    
                    //接收返回的數據
                    let responseJSON = try? JSONSerialization.jsonObject(with: data, options: [])
                    //打印出返回的JSON數據
                    print("this is responsJSON",responseJSON)
            
                    var responseJSONData: [String: Any]
                    //將返回的JSON數據轉換為[String: Any]類型
                    if let responseJSONData = responseJSON as? [String: Any] {
                     
                        //打印轉換後的[String: Any]字典
                        print("this is the resonseJSONData",responseJSONData)
                        
                        //取出[String: Any]字典中data的值
                        let individualJSONData = responseJSONData["data"]
                        
                        //打印出individualJSONData的值（為JSON數據）
                        print("This is individualJSONData from postPersonalData",individualJSONData)
                        
                        //轉換JSON數據為字典
                        let resultDictionary =  getDictionaryFromJSONString(jsonString: individualJSONData as! String)
                        
                        //  var sectionTitleOne = ["姓名","社保基数","应发工资","住房公积金公司缴纳","住房公积金个人缴纳","综合货币待遇"]
                        
                        //添加數據到數組（使用toString函數將字典中的值轉換為字符串
                        ResultViewController.dataOneArray[0] = toString(resultDictionary["user_name"])
                        ResultViewController.dataOneArray[1] = toString(resultDictionary["social_security_cardinal_number"])
                        ResultViewController.dataOneArray[2] = toString(resultDictionary["should_pay"])
                        ResultViewController.dataOneArray[3] = toString(resultDictionary["accumulation_fund_company"])
                        ResultViewController.dataOneArray[4] = toString(resultDictionary["accumulation_fund_individual"])
                        ResultViewController.dataOneArray[5] = toString(resultDictionary["comprehensive_salary"])

                        //打印數組以及數組元素個數
                        print("This is the ResultTwoViewController dataArray in SalaryCalculatorViewController",ResultTwoViewController.dataArray)
                        print("This is the ResultTwoViewController dataArray count in SalaryCalculatorViewController",ResultTwoViewController.dataArray.count)
                        print("Individual data sent")
                    }
            }
            task.resume()
    }
    
    //發送公司數據並且處理返回數據
    func postCorporateData() {
            let corporationJSON: [String: Any] = ["shenzhen_registered": self.identitySwitch.isOn ? "0":"1", "salary": self.monthlyIncomeTextField.text]

            print("this is postCorporationData")
            print("this is postCorporationJSON",corporationJSON)
            print("this is postCorporateData again")
        
            let jsonData = try? JSONSerialization.data(withJSONObject: corporationJSON)

            //設置url地址
            let url = URL(string: "http://192.168.31.22:8083/salaryCalculateCompany")!
        
            //設置request請求
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.setValue("\(String(describing: jsonData?.count))", forHTTPHeaderField: "Content-Length")
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                
            //將json插入請求
            request.httpBody = jsonData

            //傳輸數據並且處理返回數據
            let task = URLSession.shared.dataTask(with: request) { [self] data, response, error in
                guard let data = data, error == nil else {
                print(error?.localizedDescription ?? "No data")
                return
            }
           
            //將返回的數據轉換為JSON
            let responseJSON = try? JSONSerialization.jsonObject(with: data, options: [])
                
                print("this is responsJSON from postCorporateData",responseJSON)
        
                var responseJSONData: [String: Any]
                if let responseJSONData = responseJSON as? [String: Any] {
                    print("this is the resonseJSONData from ",responseJSONData) //Code after Successfull POST Request
                    
                    let coporationJSONData = responseJSONData["data"]
                    print("This is coporationJSONData", coporationJSONData)
                    
                    // 轉換JSON數據為字典
                    let resultDictionary =  getDictionaryFromJSONString(jsonString: coporationJSONData as! String)
                    
                    //添加數據到數組
                    ResultTwoViewController.dataArray[0] = toString(resultDictionary["user_name"])
                    ResultTwoViewController.dataArray[1] = toString(resultDictionary["social_security_cardinal_number"])
                    ResultTwoViewController.dataArray[2] = toString(resultDictionary["should_pay"])
                    ResultTwoViewController.dataArray[3] = toString(resultDictionary["social_insurance_company"])
                    ResultTwoViewController.dataArray[4] = toString(resultDictionary["social_insurance_individual"])
                    ResultTwoViewController.dataArray[5] = toString(resultDictionary["accumulation_fund_company"])
                    ResultTwoViewController.dataArray[6] = toString(resultDictionary["accumulation_fund_individual"])
                    ResultTwoViewController.dataArray[7] = toString(resultDictionary["comprehensive_salary"])
    
                    print("This is the ResultTwoViewController dataArray in SalaryCalculatorViewController",ResultTwoViewController.dataArray)
                    print("This is the ResultTwoViewController dataArray count in SalaryCalculatorViewController",ResultTwoViewController.dataArray.count)
                    print("postCorporateData data sent")
                }
         }
         task.resume()
    }

    //把JSON字符串轉為字典
    func getDictionaryFromJSONString(jsonString:String) ->NSDictionary {
     
         let jsonData:Data = jsonString.data(using: .utf8)!
     
         let dict = try? JSONSerialization.jsonObject(with: jsonData, options: .mutableContainers)
         if dict != nil {
            return dict as! NSDictionary
         }
         return NSDictionary()
    }
    
    //Any類型轉字符串
    func toString(_ value: Any?) -> String {
         return String(describing: value ?? "")
    }

    //顯示綜合薪酬計算TableView
    func showPersonalTableView() {
        let vc = ResultViewController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    //顯示應發工資TableView
    func showCoperationTableView() {
        let vc = ResultTwoViewController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    //個人薪酬計算
    func personalTask(completion: (_ success: Bool) -> Void) {
        postPersonalData()
        completion(true)
    }
    
    //公司薪酬計算
    func corporateTask(completion: (_ success: Bool) -> Void) {
        postCorporateData()
        completion(true)
    }
    
    //重置按鈕函數（重置所有文本框為空）
    @objc func reset() {
        
        print("reset button press")
        
        if (segmentedControl.selectedSegmentIndex == 0) {
            self.monthlyIncomeTextField.text = ""
            self.reservedTextField.text = (self.payTypeSwitch.isOn) ? "" : "0"
        } else if (segmentedControl.selectedSegmentIndex == 1) {
            self.monthlyIncomeTextField.text = ""
        }
    }
    
    //segmentcontrol觸動函數
    @IBAction func indexChanged(sender: UISegmentedControl) {
        
        switch segmentedControl.selectedSegmentIndex {
        
        //綜合薪酬模式
        case 0:
            
            self.payTypeSwitch.isEnabled = true
            self.monthlyIncomeLabel.text = "综合薪酬"

        //公司帳戶無需填寫預留工資
        case 1:
              
            self.payTypeSwitch.isEnabled = false
            self.monthlyIncomeLabel.text = "应发工资"
            
            self.reservedTextField.text = "0"
            self.reservedTextField.isEnabled = false

            print("case one reservedTextField",reservedTextField.text!)
        
        default:
            break;
        }
    }

    //payTypeSwitch開關函數
    @objc func payTypeSwitchValueChange(sender: UISwitch) {
        // 個人且為全額時
        if ((segmentedControl.selectedSegmentIndex == 0) && (!payTypeSwitch.isOn)) {
            self.reservedTextField.text = "0"
            self.reservedTextField.isEnabled = false
        } else if ((segmentedControl.selectedSegmentIndex == 0) && (payTypeSwitch.isOn)) {
                print("綜合薪酬非全額模式")
            
                self.reservedTextField.isEnabled = true
                self.reservedTextField.text = ""
        }
    }
    
    //MARK:-計算函數
    //計算按鈕函數
    @objc func calculate() {
        
        print("calculate button press")
        
        //綜合薪酬，全額模式
        if ((self.segmentedControl.selectedSegmentIndex == 0) && (!self.payTypeSwitch.isOn)) {
            if ((self.monthlyIncomeTextField.text != "0") && (self.monthlyIncomeTextField.text != "")) {
                postPersonalData()
                showPersonalTableView()
            }
            
            //提示框的顯示
            if ((self.monthlyIncomeTextField.text == "0") || (self.monthlyIncomeTextField.text == "")) {
                let alert = UIAlertController(title: "🐱提醒", message: "请输入综合薪酬", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "确认", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
        
        //綜合薪酬 非全額模式
        if ((self.segmentedControl.selectedSegmentIndex == 0) && (self.payTypeSwitch.isOn)) {
            if ((self.monthlyIncomeTextField.text != "0") && (self.monthlyIncomeTextField.text != "") && (self.reservedTextField.text != "0") && (self.reservedTextField.text != "")) {
                postPersonalData()
                showPersonalTableView()
            }
            
            //提示框的顯示
            if ((self.monthlyIncomeTextField.text == "0") || (self.monthlyIncomeTextField.text == "")) {
                let alert = UIAlertController(title: "🐱提醒", message: "请输入综合薪酬", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "确认", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
            
            //提示框的顯示
            if ((self.reservedTextField.text == "0") || (self.reservedTextField.text == "")) {
                let alert = UIAlertController(title: "🐱提醒", message: "请输入奖金", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "确认", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
        
        //應發工資模式
        if (self.segmentedControl.selectedSegmentIndex == 1) {
              if ((self.monthlyIncomeTextField.text != "") && (self.monthlyIncomeTextField.text != "0")) {
                  postCorporateData()
                  showCoperationTableView()
              }
        
              if ((self.monthlyIncomeTextField.text == "0") || (self.monthlyIncomeTextField.text == "")) {
                let alert = UIAlertController(title: "🐱提醒", message: "请输入工资", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "确认", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
}
